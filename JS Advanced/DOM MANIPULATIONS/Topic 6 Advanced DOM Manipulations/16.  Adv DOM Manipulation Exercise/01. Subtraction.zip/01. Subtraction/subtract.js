function subtract() {
    let ipTextNum1 = document.getElementById('firstNumber');
    let ipTextNum2 = document.getElementById('secondNumber');
    ipTextNum1.disabled = false;
    ipTextNum2.disabled = false;
        let num1 = Number(document.getElementById('firstNumber').value); 
        let num2 = Number(document.getElementById('secondNumber').value);
        document.getElementById('result').textContent = num1 - num2;
    ipTextNum1.addEventListener('change', function(){
        let num1 = Number(document.getElementById('firstNumber').value); 
        let num2 = Number(document.getElementById('secondNumber').value);
        document.getElementById('result').textContent = num1 - num2;
    });
    ipTextNum2.addEventListener('change', function(){
        let num1 = Number(document.getElementById('firstNumber').value); 
        let num2 = Number(document.getElementById('secondNumber').value);
        document.getElementById('result').textContent = num1 - num2;
    });
}