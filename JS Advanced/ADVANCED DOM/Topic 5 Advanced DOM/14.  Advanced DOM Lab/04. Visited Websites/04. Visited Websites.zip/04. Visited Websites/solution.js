function solve() {
  let webSites = document.querySelectorAll('.link-1');
  Array.from(webSites).forEach(site => {
      site.addEventListener(`click`, (ev) => {
          let paragraph = site.querySelector('p');
          let counter = paragraph.textContent.split(` `)[1];
          counter++;
          paragraph.innerText = `visited ${counter} times`;
      });
  });
}

// function solve() {
//   let webSites = document.getElementsByClassName("link-1");
//   console.log(webSites);
//     Array.from(webSites).map(site => {
//       site.addEventListener(`click`, (ev) => {
//           let paragraph = site.getElementsByTagName('p')[0];
//           let counter = paragraph.textContent.split(` `)[1];
//           counter++;
//           paragraph.innerText = `visited ${counter} times`;
//       });
//   });
// }
